/**
 * HAQ Airtable-Compatible REST API for PostgreSQL
 * Version: 3.0 - Full CRUD + Linked Record Resolution
 * 
 * ARCHITECTURE NOTE:
 * ==================
 * - All PostgreSQL table structures match Airtable exactly (same column names)
 * - This API uses an Airtable-compatible adapter to maintain feature parity
 * - Supports filterByFormula syntax for seamless frontend migration
 * - Resolves linked records for treatment_plans (patient, report, results)
 * - Chat and Portal both use this same adapter pattern
 * 
 * Endpoints:
 * - GET    /v0/{baseId}/{tableName}              - List records
 * - GET    /v0/{baseId}/{tableName}/{recordId}   - Get single record
 * - POST   /v0/{baseId}/{tableName}              - Create record
 * - PATCH  /v0/{baseId}/{tableName}/{recordId}   - Update record
 * - DELETE /v0/{baseId}/{tableName}/{recordId}   - Delete record
 */

const { Pool } = require('pg');

// ═══════════════════════════════════════════════════════════════════════════════
// Configuration
// ═══════════════════════════════════════════════════════════════════════════════

// Database mapping: Airtable Base ID → PostgreSQL Database
const BASE_MAP = {
  'appgiPT2PnR2JrVzI': 'haq_scoring',
  'appwE6FXQqpSz7eRh': 'haq_ontology',
  'app42HAczcSBeZOxD': 'haq_knowledge'
};

// PostgreSQL connection config
const PG_CONFIG = {
  host: process.env.PG_HOST || 'haq-postgres.cbk4u6eeybm2.us-east-2.rds.amazonaws.com',
  port: process.env.PG_PORT || 5432,
  user: process.env.PG_USER || 'haq_admin',
  password: process.env.PG_PASSWORD || 'HaqSecure2026_1cfa935e',
  ssl: { rejectUnauthorized: false }
};

// Connection pools by database
const pools = {};

function getPool(database) {
  if (!pools[database]) {
    pools[database] = new Pool({ ...PG_CONFIG, database });
  }
  return pools[database];
}

// CORS headers
const corsHeaders = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With'
};

// ═══════════════════════════════════════════════════════════════════════════════
// Airtable Record Format
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Convert PostgreSQL row to Airtable record format
 * Preserves exact column names from PostgreSQL (which match Airtable)
 */
function rowToRecord(row) {
  const fields = {};
  
  for (const [key, value] of Object.entries(row)) {
    // Skip internal columns
    if (key === 'id' || key === 'airtable_record_id' || key === 'airtable_created_time') {
      continue;
    }
    
    // Parse JSON strings back to arrays/objects
    let parsedValue = value;
    if (typeof value === 'string' && (value.startsWith('[') || value.startsWith('{'))) {
      try {
        parsedValue = JSON.parse(value);
      } catch (e) {
        // Keep as string if not valid JSON
      }
    }
    
    fields[key] = parsedValue;
  }
  
  return {
    id: row.airtable_record_id || row.id?.toString(),
    fields,
    createdTime: row.airtable_created_time || new Date().toISOString()
  };
}

/**
 * Generate Airtable-style record ID
 */
function generateRecordId() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let id = 'rec';
  for (let i = 0; i < 14; i++) {
    id += chars[Math.floor(Math.random() * chars.length)];
  }
  return id;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Linked Record Resolution
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Extract record ID from link field (handles JSON array format)
 */
function extractRecordId(linkValue) {
  if (!linkValue) return null;
  
  // If it's a JSON array like ["recXXX"], extract the ID
  if (typeof linkValue === 'string') {
    if (linkValue.startsWith('[')) {
      try {
        const arr = JSON.parse(linkValue);
        return arr[0] || null;
      } catch (e) {
        return linkValue;
      }
    }
    return linkValue;
  }
  
  // If it's already an array
  if (Array.isArray(linkValue)) {
    return linkValue[0] || null;
  }
  
  return linkValue;
}

/**
 * Resolve linked records for treatment_plans
 * Fetches patient details, report details, and related results
 */
async function resolveLinkedRecords(client, records, tableName) {
  // Only resolve for treatment_plans
  if (tableName !== 'treatment_plans') {
    return records;
  }
  
  // Collect all linked IDs
  const patientIds = new Set();
  const reportIds = new Set();
  
  for (const record of records) {
    const patientId = extractRecordId(record.fields.patient_id_link);
    const reportId = extractRecordId(record.fields.report_id_link);
    if (patientId) patientIds.add(patientId);
    if (reportId) reportIds.add(reportId);
  }
  
  // Fetch patients
  const patientMap = {};
  if (patientIds.size > 0) {
    const patientIdsArray = Array.from(patientIds);
    const placeholders = patientIdsArray.map((_, i) => `$${i + 1}`).join(', ');
    const patientResult = await client.query(
      `SELECT * FROM patients WHERE airtable_record_id IN (${placeholders})`,
      patientIdsArray
    );
    for (const row of patientResult.rows) {
      patientMap[row.airtable_record_id] = row;
    }
  }
  
  // Fetch reports
  const reportMap = {};
  if (reportIds.size > 0) {
    const reportIdsArray = Array.from(reportIds);
    const placeholders = reportIdsArray.map((_, i) => `$${i + 1}`).join(', ');
    const reportResult = await client.query(
      `SELECT * FROM reports WHERE airtable_record_id IN (${placeholders})`,
      reportIdsArray
    );
    for (const row of reportResult.rows) {
      reportMap[row.airtable_record_id] = row;
    }
  }
  
  // Fetch results for all reports (for key lab findings)
  const resultsMap = {};
  if (reportIds.size > 0) {
    const reportIdsArray = Array.from(reportIds);
    // Results link to reports via report_id_link field
    const resultsResult = await client.query(
      `SELECT * FROM results WHERE report_id_link IS NOT NULL`
    );
    for (const row of resultsResult.rows) {
      const reportId = extractRecordId(row.report_id_link);
      if (reportId) {
        if (!resultsMap[reportId]) resultsMap[reportId] = [];
        resultsMap[reportId].push(row);
      }
    }
  }
  
  // Fetch functional intake for patients (for questionnaire findings)
  const intakeMap = {};
  if (patientIds.size > 0) {
    const patientIdsArray = Array.from(patientIds);
    const intakeResult = await client.query(
      `SELECT * FROM functional_intake WHERE patient_id_link IS NOT NULL`
    );
    for (const row of intakeResult.rows) {
      const patientId = extractRecordId(row.patient_id_link);
      if (patientId) {
        intakeMap[patientId] = row;
      }
    }
  }
  
  // Enrich records with linked data
  for (const record of records) {
    const patientId = extractRecordId(record.fields.patient_id_link);
    const reportId = extractRecordId(record.fields.report_id_link);
    
    // Add patient data
    if (patientId && patientMap[patientId]) {
      const patient = patientMap[patientId];
      record.fields._patient = {
        id: patient.airtable_record_id,
        patient_id: patient.patient_id,
        first_name: patient.first_name,
        last_name: patient.last_name,
        full_name: `${patient.first_name || ''} ${patient.last_name || ''}`.trim(),
        email: patient.email,
        dob: patient.dob,
        sex: patient.sex,
        partner_id: patient.partner_id
      };
    }
    
    // Add report data
    if (reportId && reportMap[reportId]) {
      const report = reportMap[reportId];
      record.fields._report = {
        id: report.airtable_record_id,
        report_id: report.report_id,
        sample_date: report.sample_date,
        report_type: report.report_type,
        lab_name: report.lab_name
      };
    }
    
    // Add key lab findings (results outside optimal range)
    if (reportId && resultsMap[reportId]) {
      const results = resultsMap[reportId];
      // Filter for results outside optimal range
      const outsideOptimal = results.filter(r => {
        const status = (r.status || r.result_status || '').toLowerCase();
        return status === 'high' || status === 'low' || status === 'critical' || 
               status === 'outside_optimal' || status === 'abnormal';
      }).slice(0, 10); // Limit to top 10
      
      record.fields._key_lab_findings = outsideOptimal.map(r => ({
        marker_name: r.marker_name || r.test_name || r.analyte,
        value: r.result_value || r.value,
        unit: r.unit || r.units,
        status: r.status || r.result_status,
        optimal_range: r.optimal_range || `${r.optimal_low || ''}-${r.optimal_high || ''}`.trim()
      }));
    }
    
    // Add key questionnaire findings (low scores)
    if (patientId && intakeMap[patientId]) {
      const intake = intakeMap[patientId];
      const lowScoreFindings = [];
      
      // Check various intake fields for low scores
      const scoreFields = [
        'energy_score', 'sleep_score', 'stress_score', 'digestion_score',
        'mood_score', 'cognition_score', 'pain_score', 'exercise_score'
      ];
      
      for (const field of scoreFields) {
        if (intake[field] !== null && intake[field] !== undefined) {
          const score = parseFloat(intake[field]);
          if (!isNaN(score) && score <= 3) { // Low score threshold
            lowScoreFindings.push({
              category: field.replace('_score', '').replace(/_/g, ' '),
              score: score,
              max_score: 10
            });
          }
        }
      }
      
      // Also check chief complaints
      if (intake.chief_complaint || intake.primary_concerns) {
        record.fields._chief_complaints = intake.chief_complaint || intake.primary_concerns;
      }
      
      record.fields._key_questionnaire_findings = lowScoreFindings;
    }
  }
  
  return records;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Filter Formula Parser
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Parse Airtable filterByFormula to SQL WHERE clause
 * Supports:
 *   - {field} = "value" / {field} = 'value'
 *   - AND({condition1}, {condition2})
 *   - SEARCH("value", {field})
 *   - SEARCH("value", ARRAYJOIN({field}))
 *   - {field} = TRUE()
 */
async function parseFilterFormula(formula, tableName, client) {
  if (!formula || formula.trim() === '') {
    return { sql: '', params: [] };
  }
  
  const params = [];
  let paramIndex = 1;
  const conditions = [];
  
  // Handle AND(...) wrapper
  let innerFormula = formula;
  const andMatch = formula.match(/^AND\((.+)\)$/i);
  if (andMatch) {
    innerFormula = andMatch[1];
  }
  
  // Handle SEARCH pattern
  const searchPattern = /SEARCH\s*\(\s*["']([^"']+)["']\s*,\s*(?:ARRAYJOIN\s*\(\s*)?\{([^}]+)\}(?:\s*\))?\s*\)/gi;
  let searchMatch;
  let tempFormula = innerFormula;
  
  while ((searchMatch = searchPattern.exec(innerFormula)) !== null) {
    const value = searchMatch[1];
    const field = searchMatch[2];
    
    conditions.push(`"${field}"::text ILIKE $${paramIndex}`);
    params.push(`%${value}%`);
    paramIndex++;
    
    tempFormula = tempFormula.replace(searchMatch[0], 'TRUE');
  }
  
  // Handle equality: {field} = "value" or {field} = 'value'
  const eqPattern = /\{([^}]+)\}\s*=\s*["']([^"']*)["']/g;
  let eqMatch;
  
  while ((eqMatch = eqPattern.exec(tempFormula)) !== null) {
    const field = eqMatch[1];
    const value = eqMatch[2];
    
    // Handle JSON array fields (like partner_id which stores ["Formula"])
    // Check both exact match and JSON array containment
    conditions.push(`("${field}" = $${paramIndex} OR "${field}"::text LIKE $${paramIndex + 1})`);
    params.push(value);
    params.push(`%"${value}"%`);
    paramIndex += 2;
  }
  
  // Handle TRUE() pattern
  const truePattern = /\{([^}]+)\}\s*=\s*TRUE\(\)/gi;
  let trueMatch;
  
  while ((trueMatch = truePattern.exec(tempFormula)) !== null) {
    const field = trueMatch[1];
    conditions.push(`("${field}" = 'true' OR "${field}" = '1' OR "${field}"::text = 'true')`);
  }
  
  if (conditions.length === 0) {
    return { sql: '', params: [] };
  }
  
  return {
    sql: 'WHERE ' + conditions.join(' AND '),
    params
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// Request Handlers
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * GET /v0/{baseId}/{tableName} - List records
 * GET /v0/{baseId}/{tableName}/{recordId} - Get single record
 */
async function handleGet(pool, tableName, recordId, queryParams) {
  const client = await pool.connect();
  
  try {
    // Normalize table name (lowercase, replace spaces with underscores)
    const normalizedTable = tableName.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    if (recordId) {
      // Single record lookup
      const result = await client.query(
        `SELECT * FROM "${normalizedTable}" WHERE "airtable_record_id" = $1 LIMIT 1`,
        [recordId]
      );
      
      if (result.rows.length === 0) {
        return { statusCode: 404, body: { error: 'Record not found' } };
      }
      
      let records = [rowToRecord(result.rows[0])];
      
      // Resolve linked records
      records = await resolveLinkedRecords(client, records, normalizedTable);
      
      return { statusCode: 200, body: records[0] };
    }
    
    // List records
    let sql = `SELECT * FROM "${normalizedTable}"`;
    let params = [];
    
    // Parse filterByFormula
    if (queryParams.filterByFormula) {
      const filter = await parseFilterFormula(queryParams.filterByFormula, normalizedTable, client);
      if (filter.sql) {
        sql += ` ${filter.sql}`;
        params = filter.params;
      }
    }
    
    // Add sorting
    if (queryParams['sort[0][field]']) {
      const sortField = queryParams['sort[0][field]'];
      const sortDir = queryParams['sort[0][direction]'] === 'desc' ? 'DESC' : 'ASC';
      sql += ` ORDER BY "${sortField}" ${sortDir} NULLS LAST`;
    }
    
    // Add limit
    const maxRecords = parseInt(queryParams.maxRecords) || 100;
    sql += ` LIMIT ${maxRecords}`;
    
    console.log(`[GET] ${normalizedTable}: ${sql}`);
    const result = await client.query(sql, params);
    
    let records = result.rows.map(rowToRecord);
    
    // Resolve linked records for treatment_plans
    if (normalizedTable === 'treatment_plans') {
      records = await resolveLinkedRecords(client, records, normalizedTable);
    }
    
    return {
      statusCode: 200,
      body: {
        records
      }
    };
    
  } finally {
    client.release();
  }
}

/**
 * POST /v0/{baseId}/{tableName} - Create record
 */
async function handlePost(pool, tableName, body) {
  const client = await pool.connect();
  
  try {
    const normalizedTable = tableName.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const fields = body.fields || body;
    
    // Build INSERT statement
    const columns = ['airtable_record_id', 'airtable_created_time'];
    const values = [generateRecordId(), new Date().toISOString()];
    const placeholders = ['$1', '$2'];
    let paramIndex = 3;
    
    for (const [field, value] of Object.entries(fields)) {
      columns.push(`"${field}"`);
      values.push(typeof value === 'object' ? JSON.stringify(value) : value);
      placeholders.push(`$${paramIndex}`);
      paramIndex++;
    }
    
    const sql = `INSERT INTO "${normalizedTable}" (${columns.join(', ')}) VALUES (${placeholders.join(', ')}) RETURNING *`;
    console.log(`[POST] ${normalizedTable}: Creating record`);
    
    const result = await client.query(sql, values);
    
    return {
      statusCode: 200,
      body: rowToRecord(result.rows[0])
    };
    
  } finally {
    client.release();
  }
}

/**
 * PATCH /v0/{baseId}/{tableName}/{recordId} - Update record
 */
async function handlePatch(pool, tableName, recordId, body) {
  const client = await pool.connect();
  
  try {
    const normalizedTable = tableName.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    const fields = body.fields || body;
    
    // Build UPDATE statement
    const setClauses = [];
    const params = [recordId];
    let paramIndex = 2;
    
    for (const [field, value] of Object.entries(fields)) {
      setClauses.push(`"${field}" = $${paramIndex}`);
      params.push(typeof value === 'object' ? JSON.stringify(value) : value);
      paramIndex++;
    }
    
    if (setClauses.length === 0) {
      return { statusCode: 400, body: { error: 'No fields to update' } };
    }
    
    const sql = `UPDATE "${normalizedTable}" SET ${setClauses.join(', ')} WHERE "airtable_record_id" = $1 RETURNING *`;
    console.log(`[PATCH] ${normalizedTable}/${recordId}: Updating ${setClauses.length} fields`);
    
    const result = await client.query(sql, params);
    
    if (result.rows.length === 0) {
      return { statusCode: 404, body: { error: 'Record not found' } };
    }
    
    return {
      statusCode: 200,
      body: rowToRecord(result.rows[0])
    };
    
  } finally {
    client.release();
  }
}

/**
 * DELETE /v0/{baseId}/{tableName}/{recordId} - Delete record
 */
async function handleDelete(pool, tableName, recordId) {
  const client = await pool.connect();
  
  try {
    const normalizedTable = tableName.toLowerCase().replace(/[^a-z0-9_]/g, '_');
    
    const result = await client.query(
      `DELETE FROM "${normalizedTable}" WHERE "airtable_record_id" = $1 RETURNING "airtable_record_id"`,
      [recordId]
    );
    
    if (result.rows.length === 0) {
      return { statusCode: 404, body: { error: 'Record not found' } };
    }
    
    console.log(`[DELETE] ${normalizedTable}/${recordId}: Deleted`);
    
    return {
      statusCode: 200,
      body: { id: recordId, deleted: true }
    };
    
  } finally {
    client.release();
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Lambda Handler
// ═══════════════════════════════════════════════════════════════════════════════

exports.handler = async (event) => {
  const method = event.httpMethod || event.requestContext?.http?.method;
  
  // Handle CORS preflight
  if (method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // Parse request path: /v0/{baseId}/{tableName} or /v0/{baseId}/{tableName}/{recordId}
    const path = event.path || event.rawPath;
    const match = path.match(/\/v0\/([^/]+)\/([^/]+)(?:\/([^/]+))?/);
    
    if (!match) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid path. Expected: /v0/{baseId}/{tableName}' })
      };
    }
    
    const [, baseId, tableName, recordId] = match;
    const database = BASE_MAP[baseId];
    
    if (!database) {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({ error: `Base not found: ${baseId}` })
      };
    }
    
    // Get database pool
    const pool = getPool(database);
    
    // Parse query params and body
    const queryParams = event.queryStringParameters || {};
    let body = {};
    if (event.body) {
      try {
        body = JSON.parse(event.body);
      } catch (e) {
        return {
          statusCode: 400,
          headers: corsHeaders,
          body: JSON.stringify({ error: 'Invalid JSON body' })
        };
      }
    }
    
    // Route to appropriate handler
    let result;
    
    switch (method) {
      case 'GET':
        result = await handleGet(pool, tableName, recordId, queryParams);
        break;
      case 'POST':
        result = await handlePost(pool, tableName, body);
        break;
      case 'PATCH':
      case 'PUT':
        if (!recordId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Record ID required for update' })
          };
        }
        result = await handlePatch(pool, tableName, recordId, body);
        break;
      case 'DELETE':
        if (!recordId) {
          return {
            statusCode: 400,
            headers: corsHeaders,
            body: JSON.stringify({ error: 'Record ID required for delete' })
          };
        }
        result = await handleDelete(pool, tableName, recordId);
        break;
      default:
        return {
          statusCode: 405,
          headers: corsHeaders,
          body: JSON.stringify({ error: `Method not allowed: ${method}` })
        };
    }
    
    return {
      statusCode: result.statusCode,
      headers: corsHeaders,
      body: JSON.stringify(result.body)
    };
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message })
    };
  }
};
